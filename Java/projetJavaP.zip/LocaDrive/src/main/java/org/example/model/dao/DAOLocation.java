package org.example.model.dao;

public class DAOLocation {

}
