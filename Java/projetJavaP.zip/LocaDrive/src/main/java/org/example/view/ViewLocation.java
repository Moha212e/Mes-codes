package org.example.view;

import org.example.model.entity.Client;

public interface ViewLocation {


}
