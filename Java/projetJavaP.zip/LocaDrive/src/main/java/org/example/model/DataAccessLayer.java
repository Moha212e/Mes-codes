package org.example.model;

import org.example.model.entity.Reservation;

public interface DataAccessLayer {

}
