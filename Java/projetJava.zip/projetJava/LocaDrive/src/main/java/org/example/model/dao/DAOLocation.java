package org.example.model.dao;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.example.model.DataAccessLayer;
import org.example.model.entity.Car;
import org.example.model.entity.Client;
import org.example.model.entity.Contrat;
import org.example.model.entity.Reservation;
import org.example.model.entity.StatutContrat;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Date;

/**
 * Implémentation de l'interface DataAccessLayer pour gérer les données de l'application.
 * Cette classe utilise JSON pour stocker les données dans des fichiers.
 */
public class DAOLocation implements DataAccessLayer {
    // Chemins des fichiers de données
    private static final String DATA_DIR = "data";
    private static final String RESERVATIONS_FILE = DATA_DIR + File.separator + "reservations.json";
    private static final String CARS_FILE = DATA_DIR + File.separator + "cars.json";
    private static final String CONTRACTS_FILE = DATA_DIR + File.separator + "contracts.json";
    private static final String CLIENTS_FILE = DATA_DIR + File.separator + "clients.json";
    private static final String COUNTERS_FILE = DATA_DIR + File.separator + "counters.json";
    
    // ObjectMapper pour la sérialisation/désérialisation JSON
    private final ObjectMapper objectMapper;
    
    // Générateurs d'ID
    private AtomicInteger reservationIdGenerator;
    private AtomicInteger carIdGenerator;
    private AtomicInteger contractIdGenerator;
    private AtomicInteger clientIdGenerator;
    
    // Collections pour stocker les données
    private Map<Integer, Reservation> reservations;
    private Map<String, Car> cars;
    private Map<String, Contrat> contracts;
    private Map<Integer, Client> clients;
    
    /**
     * Constructeur qui initialise les collections et charge les données depuis les fichiers.
     */
    public DAOLocation() {
        // Initialiser l'ObjectMapper pour la sérialisation/désérialisation JSON
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule()); // Support pour java.time (LocalDate, etc.)
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT); // Pour un JSON formaté
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); // Ignorer les propriétés inconnues
        
        // Initialiser les collections
        reservations = new HashMap<>();
        cars = new HashMap<>();
        contracts = new HashMap<>();
        clients = new HashMap<>();
        
        // Initialiser les générateurs d'ID
        reservationIdGenerator = new AtomicInteger(1);
        carIdGenerator = new AtomicInteger(1);
        contractIdGenerator = new AtomicInteger(1);
        clientIdGenerator = new AtomicInteger(1);
        
        // Créer le répertoire de données s'il n'existe pas
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }
        
        // Charger les données depuis les fichiers
        loadData();
        
        // Si aucune donnée n'a été chargée, initialiser avec des données de démonstration
        if (reservations.isEmpty() && cars.isEmpty() && contracts.isEmpty() && clients.isEmpty()) {
            //initDemoData();
            //saveData(); // Sauvegarder immédiatement les données de démonstration
        }
    }

    /**
     * Charge les données depuis les fichiers JSON.
     */
    private void loadData() {
        try {
            // Charger les compteurs
            File countersFile = new File(COUNTERS_FILE);
            if (countersFile.exists()) {
                Map<String, Integer> counters = objectMapper.readValue(countersFile, TypeFactory.defaultInstance().constructMapType(Map.class, String.class, Integer.class));
                reservationIdGenerator = new AtomicInteger(counters.get("reservationId"));
                carIdGenerator = new AtomicInteger(counters.get("carId"));
                contractIdGenerator = new AtomicInteger(counters.get("contractId"));
                clientIdGenerator = new AtomicInteger(counters.get("clientId"));
            }
            
            // Charger les voitures
            File carsFile = new File(CARS_FILE);
            if (carsFile.exists()) {
                cars = objectMapper.readValue(carsFile, TypeFactory.defaultInstance().constructMapType(Map.class, String.class, Car.class));
            }
            
            // Charger les clients
            File clientsFile = new File(CLIENTS_FILE);
            if (clientsFile.exists()) {
                clients = objectMapper.readValue(clientsFile, TypeFactory.defaultInstance().constructMapType(Map.class, Integer.class, Client.class));
            }
            
            // Charger les contrats
            File contractsFile = new File(CONTRACTS_FILE);
            if (contractsFile.exists()) {
                contracts = objectMapper.readValue(contractsFile, TypeFactory.defaultInstance().constructMapType(Map.class, String.class, Contrat.class));
            }
            
            // Charger les réservations
            File reservationsFile = new File(RESERVATIONS_FILE);
            if (reservationsFile.exists()) {
                reservations = objectMapper.readValue(reservationsFile, TypeFactory.defaultInstance().constructMapType(Map.class, Integer.class, Reservation.class));
            }
            
            // Restaurer les références entre les objets
            restoreReferences();
            
            // Afficher un résumé des données chargées
            printDataSummary();
            
            System.out.println("Données chargées avec succès.");
        } catch (IOException e) {
            System.err.println("Erreur lors du chargement des données: " + e.getMessage());
            e.printStackTrace();
            
            // Réinitialiser les collections en cas d'erreur
            reservations = new HashMap<>();
            cars = new HashMap<>();
            contracts = new HashMap<>();
            clients = new HashMap<>();
        }
    }
    
    /**
     * Affiche un résumé des données chargées.
     */
    private void printDataSummary() {
        System.out.println("=== RÉSUMÉ DES DONNÉES ===");
        System.out.println("Voitures: " + cars.size());
        for (Car car : cars.values()) {
            System.out.println(" - " + car.getIdCar() + ": " + car.getBrand() + " " + car.getModel());
        }
        
        System.out.println("Clients: " + clients.size());
        for (Client client : clients.values()) {
            System.out.println(" - " + client.getIdClient() + ": " + client.getName() + " " + client.getSurname());
        }
        
        System.out.println("Contrats: " + contracts.size());
        for (Contrat contrat : contracts.values()) {
            System.out.println(" - " + contrat.getIdContrat() + ": " + contrat.getTypeAssurance() + " (Caution: " + contrat.getCaution() + "€)");
        }
        
        System.out.println("Réservations: " + reservations.size());
        for (Reservation reservation : reservations.values()) {
            String carInfo = reservation.getCar() != null ? 
                    reservation.getCar().getBrand() + " " + reservation.getCar().getModel() : 
                    "Voiture inconnue (ID: " + reservation.getCarId() + ")";
            
            String clientInfo = reservation.getClient() != null ? 
                    reservation.getClient().getName() + " " + reservation.getClient().getSurname() : 
                    "Client inconnu (ID: " + reservation.getClientId() + ")";
            
            System.out.println(" - " + reservation.getIdReservation() + ": " + carInfo + " pour " + clientInfo);
        }
        System.out.println("=========================");
    }
    
    /**
     * Restaure les références entre les objets après la désérialisation.
     */
    private void restoreReferences() {
        // Restaurer les références dans les réservations
        for (Reservation reservation : reservations.values()) {
            // Restaurer la référence à la voiture
            if (reservation.getCarId() != null && !reservation.getCarId().isEmpty()) {
                Car car = cars.get(reservation.getCarId());
                if (car != null) {
                    reservation.setCar(car);
                } else {
                    System.err.println("Erreur: Voiture avec ID " + reservation.getCarId() + " non trouvée pour la réservation " + reservation.getIdReservation());
                }
            }
            
            // Restaurer la référence au client
            if (reservation.getClientId() > 0) {
                Client client = clients.get(reservation.getClientId());
                if (client != null) {
                    reservation.setClient(client);
                } else {
                    System.err.println("Erreur: Client avec ID " + reservation.getClientId() + " non trouvé pour la réservation " + reservation.getIdReservation());
                }
            }
            
            // Restaurer la référence au contrat
            if (reservation.getContratId() != null && !reservation.getContratId().isEmpty()) {
                Contrat contrat = contracts.get(reservation.getContratId());
                if (contrat != null) {
                    reservation.setContrat(contrat);
                } else {
                    System.err.println("Erreur: Contrat avec ID " + reservation.getContratId() + " non trouvé pour la réservation " + reservation.getIdReservation());
                }
            }
        }
        
        System.out.println("Références restaurées avec succès.");
    }
    
    /**
     * Sauvegarde les données dans des fichiers JSON.
     */
    private void saveData() {
        try {
            // Sauvegarder les compteurs
            Map<String, Integer> counters = new HashMap<>();
            counters.put("reservationId", reservationIdGenerator.get());
            counters.put("carId", carIdGenerator.get());
            counters.put("contractId", contractIdGenerator.get());
            counters.put("clientId", clientIdGenerator.get());
            objectMapper.writeValue(new File(COUNTERS_FILE), counters);
            
            // Sauvegarder les réservations
            objectMapper.writeValue(new File(RESERVATIONS_FILE), reservations);
            
            // Sauvegarder les voitures
            objectMapper.writeValue(new File(CARS_FILE), cars);
            
            // Sauvegarder les contrats
            objectMapper.writeValue(new File(CONTRACTS_FILE), contracts);
            
            // Sauvegarder les clients
            objectMapper.writeValue(new File(CLIENTS_FILE), clients);
            
            System.out.println("Données sauvegardées avec succès.");
        } catch (IOException e) {
            System.err.println("Erreur lors de la sauvegarde des données: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public int addReservation(Reservation reservation) {
        if (reservation.getIdReservation() == 0) {
            int id = reservationIdGenerator.getAndIncrement();
            reservation.setIdReservation(id);
        }
        reservations.put(reservation.getIdReservation(), reservation);
        saveData(); // Sauvegarder après modification
        return reservation.getIdReservation();
    }

    public int addCar(Car car) {
        if (car.getIdCar() == null || car.getIdCar().isEmpty()) {
            // Générer un ID d'immatriculation si nécessaire
            String id = "1-XYZ-" + carIdGenerator.getAndIncrement();
            car.setIdCar(id);
        }
        cars.put(car.getIdCar(), car);
        saveData(); // Sauvegarder après modification
        return 1; // Succès
    }

    public int addContract(Contrat contrat) {
        if (contrat.getIdContrat() == null || contrat.getIdContrat().isEmpty()) {
            String id = "C" + contractIdGenerator.getAndIncrement();
            contrat.setIdContrat(id);
        }
        contracts.put(contrat.getIdContrat(), contrat);
        saveData(); // Sauvegarder après modification
        return 1; // Succès
    }

    public int addClient(Client client) {
        if (client.getIdClient() == 0) {
            int id = clientIdGenerator.getAndIncrement();
            client.setIdClient(id);
        }
        clients.put(client.getIdClient(), client);
        saveData(); // Sauvegarder après modification
        return client.getIdClient();
    }

    public boolean deleteReservation(Reservation reservation) {
        boolean result = reservations.remove(reservation.getIdReservation()) != null;
        if (result) {
            saveData(); // Sauvegarder après modification
        }
        return result;
    }

    public boolean deleteCar(Car car) {
        // Au lieu de marquer comme supprimé, on retire la voiture de la disponibilité
        Car existingCar = cars.get(car.getIdCar());
        if (existingCar != null) {
            existingCar.setAvailable(false);
            saveData(); // Sauvegarder après modification
            return true;
        }
        return false;
    }

    public boolean deleteContract(Contrat contrat) {
        // Annuler le contrat plutôt que de le supprimer
        Contrat existingContract = contracts.get(contrat.getIdContrat());
        if (existingContract != null) {
            existingContract.setStatutContrat(StatutContrat.ANNULE);
            saveData(); // Sauvegarder après modification
            return true;
        }
        return false;
    }

    public boolean deleteClient(Client client) {
        // Au lieu de marquer comme supprimé, on pourrait simplement supprimer le client
        // ou implémenter une autre logique métier (désactiver le compte, etc.)
        Client existingClient = clients.get(client.getIdClient());
        if (existingClient != null) {
            // On pourrait ajouter une propriété 'active' à Client si nécessaire
            // Pour l'instant, on supprime simplement le client
            clients.remove(client.getIdClient());
            saveData(); // Sauvegarder après modification
            return true;
        }
        return false;
    }

    public void updateReservation(Reservation reservation) {

    }

    public void updateCar(Car car) {

    }

    public void updateContract(Contrat contrat) {

    }

    public void updateClient(Client client) {
        if (clients.containsKey(client.getIdClient())) {
            clients.put(client.getIdClient(), client);
            saveData(); // Sauvegarder après modification
        }
    }
    
    /**
     * Récupère toutes les réservations.
     * 
     * @return Liste de toutes les réservations
     */
    public List<Reservation> getAllReservations() {
        return new ArrayList<>(reservations.values());
    }

    public List<Car> getAllCars() {
        return new ArrayList<>(cars.values());
    }

    public List<Contrat> getAllContracts() {
        return new ArrayList<>(contracts.values());
    }

    public List<Client> getAllClients() {
        return new ArrayList<>(clients.values());
    }
    
    /**
     * Récupère une réservation par son ID.
     * 
     * @param id ID de la réservation
     * @return La réservation ou null si non trouvée
     */
    public Reservation getReservationById(int id) {
        return reservations.get(id);
    }
    
    /**
     * Récupère une voiture par son ID.
     * 
     * @param id ID de la voiture
     * @return La voiture ou null si non trouvée
     */
    public Car getCarById(String id) {
        return cars.get(id);
    }

    @Override
    public void getListCar() {


    }

    /**
     * Récupère un contrat par son ID.
     * 
     * @param id ID du contrat
     * @return Le contrat ou null si non trouvé
     */
    public Contrat getContractById(String id) {
        return contracts.get(id);
    }
    
    /**
     * Récupère un client par son ID.
     * 
     * @param id ID du client
     * @return Le client ou null si non trouvé
     */
    public Client getClientById(int id) {
        return clients.get(id);
    }
    
    /**
     * Récupère un client par son email.
     * 
     * @param email Email du client
     * @return Le client ou null si non trouvé
     */
    public Client getClientByEmail(String email) {
        List<Client> clients = getAllClients();
        for (Client client : clients) {
            if (client.getEmail().equals(email)) {
                return client;
            }
        }
        return null;
    }

    /**
     * Récupère les réservations d'un client.
     * 
     * @param clientId ID du client
     * @return Liste des réservations du client
     */
    public List<Reservation> getReservationsByClient(int clientId) {
        List<Reservation> clientReservations = new ArrayList<>();
        for (Reservation reservation : reservations.values()) {
            if (reservation.getClient() != null && reservation.getClient().getIdClient() == clientId) {
                clientReservations.add(reservation);
            }
        }
        return clientReservations;
    }
    
    /**
     * Récupère les voitures disponibles pour une période donnée.
     * 
     * @param startDate Date de début
     * @param endDate Date de fin
     * @return Liste des voitures disponibles
     */
    public List<Car> getAvailableCars(LocalDate startDate, LocalDate endDate) {
        List<Car> allCars = getAllCars();
        List<Car> availableCars = new ArrayList<>();

        for (Car car : allCars) {
            if (car.isAvailable()) {
                availableCars.add(car);
            }
        }

        return availableCars;
    }
}
