package org.example.view;

import org.example.controller.Controller;
import org.example.model.entity.Car;
import org.example.model.entity.Client;
import org.example.model.entity.Contrat;
import org.example.model.entity.Reservation;

import java.util.ArrayList;
import java.util.List;

public interface ViewLocation {

    void run();
    void showErrorMessage(String message);
    void showMessage(String message);
    void setController(Controller controller);
    void showAddLocationFormFromController();
    void showAddCarFormFromController();
    void showSessionDialogFromController();
    
    // Nouvelles méthodes pour mettre à jour les tables
    void updateCarTable(List<Car> cars);
    void updateClientTable(List<Client> clients);
    void updateReservationTable(List<Reservation> reservations);
    
    // Méthode pour mettre à jour l'affichage des images de voitures
    void updateCarImages(List<Car> cars);
    
    // Méthodes pour la modification des voitures
    Car getSelectedCar();
    void showModifyCarFormFromController(Car car);

    Car promptAddCar();

    Client promptAddClient();

    Reservation promptAddLocation();

    Contrat promptAddContrat();

    void updateContratTable(List<Contrat> contrats);
    
    // Méthode pour afficher les détails d'une voiture
    void showCarDetails(Car car);
}
