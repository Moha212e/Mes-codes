package org.example.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

/**
 * 
 */
public class Reservation implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int idReservation;
    
    @JsonIgnore
    private transient Car car;
    
    @JsonIgnore
    private transient Client client;
    
    private Date startDate;
    private Date endDate;
    private String responsable;
    private String notes;
    private float price;
    
    @JsonIgnore
    private transient Contrat contrat;
    
    // Attributs pour stocker les identifiants lors de la sérialisation
    private String carId;
    private int clientId;
    private String contratId;

    public Reservation() {
        this.idReservation = 0;
        this.startDate = null;
        this.endDate = null;
        this.responsable = "";
        this.notes = "";
        this.price = 0;
    }

    public Reservation(int idReservation, Date startDate, Date endDate, String responsable, String notes, float price) {
        this.idReservation = idReservation;
        this.startDate = startDate;
        this.endDate = endDate;
        this.responsable = responsable;
        this.notes = notes;
        this.price = price;
    }

    public Reservation(int idReservation, Car car, Client client, LocalDate startDate, LocalDate endDate, String responsable, float price, String notes, Contrat contrat) {
        this.idReservation = idReservation;
        this.car = car;
        this.client = client;
        this.startDate = Date.from(startDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        this.endDate = Date.from(endDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        this.responsable = responsable;
        this.notes = notes;
        this.price = price;
        this.contrat = contrat;
        
        // Stocker les identifiants
        if (car != null) {
            this.carId = car.getIdCar();
        }
        if (client != null) {
            this.clientId = client.getIdClient();
        }
        if (contrat != null) {
            this.contratId = contrat.getIdContrat();
        }
    }

    public int getIdReservation() {
        return idReservation;
    }

    public void setIdReservation(int idReservation) {
        this.idReservation = idReservation;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
        if (car != null) {
            this.carId = car.getIdCar();
        } else {
            this.carId = null;
        }
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
        if (client != null) {
            this.clientId = client.getIdClient();
        } else {
            this.clientId = 0;
        }
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getResponsable() {
        return responsable;
    }

    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }

    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    public float getPrice() {
        return price;
    }
    
    public void setPrice(float price) {
        this.price = price;
    }
    
    public Contrat getContrat() {
        return contrat;
    }
    
    public void setContrat(Contrat contrat) {
        this.contrat = contrat;
        if (contrat != null) {
            this.contratId = contrat.getIdContrat();
        } else {
            this.contratId = null;
        }
    }

    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getContratId() {
        return contratId;
    }

    public void setContratId(String contratId) {
        this.contratId = contratId;
    }

    @Override
    public String toString() {
        return STR."Reservation{idReservation=\{idReservation}, startDate=\{startDate}, endDate=\{endDate}, responsable='\{responsable}', notes='\{notes}', price=\{price}}";
    }
}
