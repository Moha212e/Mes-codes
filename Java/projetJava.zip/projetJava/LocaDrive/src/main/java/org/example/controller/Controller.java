package org.example.controller;

import org.example.model.DataAccessLayer;
import org.example.model.dao.DAOLocation;
import org.example.model.entity.Car;
import org.example.model.entity.Client;
import org.example.model.entity.Contrat;
import org.example.model.entity.Reservation;
import org.example.view.GUI.JFramesLocation;
import org.example.view.ViewLocation;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class Controller implements ActionListener {
    
    private DataAccessLayer model;
    private ViewLocation view;
    
    public Controller() {
        // Constructeur par défaut
    }
    
    public void run(){
        view.run();
    }

    public Controller(DataAccessLayer data, ViewLocation view) {
        this.model = data;
        this.view = view;
        this.view.setController(this);
        
        // Mettre à jour les tables au démarrage
        updateAllTables();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        System.out.println(STR."Action reçue: \{command}");
        
        switch (command) {
            case ControllerActions.SESSION:
                handleSession();
                break;
            case ControllerActions.ADD_CAR:
                handleAddCar();
                break;
            case ControllerActions.MODIFY_CAR:
                handleModifyCar();
                break;
            case ControllerActions.DELETE_CAR:
                handleDeleteCar();
                break;
            case ControllerActions.ADD_CLIENT:
                handleAddClient();
                break;
            case ControllerActions.MODIFY_CLIENT:
                handleModifyClient();
                break;
            case ControllerActions.DELETE_CLIENT:
                handleDeleteClient();
                break;
            case ControllerActions.ADD_LOCATION:
                handleAddLocation();
                break;
            case ControllerActions.MODIFY_LOCATION:
                handleModifyLocation();
                break;
            case ControllerActions.DELETE_LOCATION:
                handleDeleteLocation();
                break;
            case ControllerActions.LOGIN:
                handleLogin();
                break;
            case ControllerActions.REGISTER:
                handleRegister();
                break;
            case ControllerActions.ADD_CONTRAT:
                handleAddContrat();
                break;
            case ControllerActions.MODIFY_CONTRAT:
                handleModifyContrat();
                break;
            case ControllerActions.DELETE_CONTRAT:
                handleDeleteContrat();
                break;
            case ControllerActions.SHOW_CAR_DETAILS:
                if (e.getSource() instanceof JComponent) {
                    JComponent source = (JComponent) e.getSource();
                    if (source.getClientProperty("car") instanceof Car) {
                        Car car = (Car) source.getClientProperty("car");
                        handleShowCarDetails(car);
                    }
                }
                break;
            case ControllerActions.CLOSE_DETAILS:
                if (e.getSource() instanceof JComponent) {
                    JComponent source = (JComponent) e.getSource();
                    if (source.getClientProperty("dialog") instanceof javax.swing.JDialog) {
                        javax.swing.JDialog dialog = (javax.swing.JDialog) source.getClientProperty("dialog");
                        dialog.dispose();
                    }
                }
                break;
            default:
                System.out.println("Commande non reconnue: " + command);
                break;
        }
    }
    
    // Méthodes de gestion des actions
    private void handleSession() {
        System.out.println("Gestion de la session");
        view.showSessionDialogFromController();

        view.showMessage("Gestion de la session");
    }
    
    private void handleAddCar() {
        Car a = view.promptAddCar();
        if(a!=null){
            model.addCar(a);
            ArrayList<Car> cars = (ArrayList<Car>) model.getAllCars();
            view.updateCarTable(cars);
            view.showMessage("Voiture ajoutée");

        }
    }
    
    private void handleModifyCar() {
        System.out.println("Modification d'un véhicule");
        // Récupérer la voiture sélectionnée dans la table
        Car selectedCar = view.getSelectedCar();
        
        if (selectedCar != null) {
            // Afficher le formulaire avec les données de la voiture sélectionnée
            view.showModifyCarFormFromController(selectedCar);
            updateCarTable();
        } else {
            // Aucune voiture sélectionnée
            view.showMessage("Veuillez sélectionner un véhicule à modifier");
        }
    }
    
    private void handleDeleteCar() {
        System.out.println("Suppression d'un véhicule");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Sélectionnez un véhicule à supprimer");
        updateCarTable();
    }
    
    private void handleAddClient() {
        Client a = view.promptAddClient();
        if(a!=null){
            model.addClient(a);
            ArrayList<Client> clients = (ArrayList<Client>) model.getAllClients();
            view.updateClientTable(clients);
            view.showMessage("Client ajouté");
        }
    }
    
    private void handleModifyClient() {

    }
    
    private void handleDeleteClient() {
    }
    
    private void handleAddLocation() {
        Reservation a = view.promptAddLocation();
        if(a!=null){
            model.addReservation(a);
            ArrayList<Reservation> reservations = (ArrayList<Reservation>) model.getAllReservations();
            view.updateReservationTable(reservations);
            view.showMessage("Location ajoutée");
        }
    }
    
    private void handleModifyLocation() {
        System.out.println("Modification d'une location");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Sélectionnez une location à modifier");
        updateReservationTable();
    }
    
    private void handleDeleteLocation() {
        System.out.println("Suppression d'une location");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Sélectionnez une location à supprimer");
        updateReservationTable();
    }
    
    private void handleLogin() {
        System.out.println("Connexion");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Connexion en cours...");
    }
    
    private void handleRegister() {
        System.out.println("Inscription");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Inscription en cours...");
    }
    
    // Méthodes de gestion des contrats
    private void handleAddContrat() {
        System.out.println("Ajout d'un contrat");
        Contrat c = view.promptAddContrat();
        if (c != null) {
            model.addContract(c);
            ArrayList<Contrat> contrats = (ArrayList<Contrat>) model.getAllContracts();
            view.updateContratTable(contrats);
            view.showMessage("Contrat ajouté");
        }
    }
    
    private void handleModifyContrat() {
        System.out.println("Modification d'un contrat");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Modification d'un contrat en cours...");
    }
    
    private void handleDeleteContrat() {
        System.out.println("Suppression d'un contrat");
        // Utiliser les méthodes disponibles dans l'interface ViewLocation
        view.showMessage("Suppression d'un contrat en cours...");
    }
    
    /**
     * Affiche les détails d'une voiture
     * @param car La voiture dont on veut afficher les détails
     */
    public void handleShowCarDetails(Car car) {
        if (car != null) {
            view.showCarDetails(car);
        }
    }
    
    /**
     * Méthode publique pour afficher les détails d'une voiture
     * Cette méthode est appelée directement par la vue
     * @param car La voiture dont on veut afficher les détails
     */
    public void showCarDetails(Car car) {
        handleShowCarDetails(car);
    }
    
    /**
     * Met à jour toutes les tables de l'interface utilisateur avec les données du modèle.
     */
    public void updateAllTables() {
        updateCarTable();
        updateClientTable();
        updateReservationTable();
        updateContratTable();
    }
    
    /**
     * Met à jour la table des voitures avec les données du modèle.
     */
    private void updateCarTable() {
        List<Car> cars = model.getAllCars();
        view.updateCarTable(cars);
        view.updateCarImages(cars); // Mettre à jour l'affichage des images de voitures
    }
    
    /**
     * Met à jour la table des clients avec les données du modèle.
     */
    private void updateClientTable() {
        List<Client> clients = model.getAllClients();
        view.updateClientTable(clients);
    }
    
    /**
     * Met à jour la table des réservations avec les données du modèle.
     */
    private void updateReservationTable() {
        List<Reservation> reservations = model.getAllReservations();
        view.updateReservationTable(reservations);
    }
    
    /**
     * Met à jour la table des contrats avec les données du modèle.
     */
    private void updateContratTable() {
        List<Contrat> contrats = model.getAllContracts();
        view.updateContratTable(contrats);
    }
    
    /**
     * Récupère une voiture par son identifiant
     * @param idCar L'identifiant de la voiture à récupérer
     * @return La voiture correspondante ou null si non trouvée
     */
    public Car getCarById(String idCar) {
        return model.getCarById(idCar);
    }

    /**
     * Met à jour une réservation dans le modèle
     * @param reservation La réservation à mettre à jour
     */
    public void updateReservation(Reservation reservation) {

    }

    /**
     * Récupère toutes les réservations du modèle
     * @return La liste des réservations
     */
    public List<Reservation> getAllReservations() {
        return model.getAllReservations();
    }
    
    /**
     * Récupère toutes les voitures du modèle
     * @return La liste des voitures
     */
    public List<Car> getAllCars() {
        return model.getAllCars();
    }
}
