﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace voyaggo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
