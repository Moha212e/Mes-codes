﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voyagoo
{
    public partial class IndexAdmin
    {
        public IndexAdmin()
        {
            InitializeComponent();
        }

        private void GererVoyages_Click(object sender, System.Windows.RoutedEventArgs e)
        {
        }

        private void EditerUtilisateur_Click(object sender, System.Windows.RoutedEventArgs e)
        {
        }

        private void ListerReservations_Click(object sender, System.Windows.RoutedEventArgs e)
        {
        }

        private void AjouterVoyages_Click(object sender, System.Windows.RoutedEventArgs e)
        {
        }
    }
}